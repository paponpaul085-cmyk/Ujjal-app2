//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BhgYEYmQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CUbzT_me.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CUbzT_me.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-l7yfQrS_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
