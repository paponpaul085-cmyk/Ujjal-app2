import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as Download, n as RotateCcw, r as Eraser } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C3FXxKk2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium outline-none transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-surface-2 text-fg shadow-[var(--shadow-border)] hover:bg-surface-2/80",
			ghost: "text-fg hover:bg-surface-2",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:bg-surface-2"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			icon: "size-11",
			"icon-sm": "size-9"
		},
		motion: {
			tap: "active:not-disabled:scale-[0.96]",
			none: ""
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default",
		motion: "tap"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, motion, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		ref,
		className: cn(buttonVariants({
			variant,
			size,
			motion,
			className
		})),
		...props
	});
});
Button.displayName = "Button";
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex h-11 w-full touch-none items-center select-none", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-surface-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-primary shadow-[0_0_0_1px_var(--color-border)] outline-none transition-[box-shadow,transform] duration-(--motion-quick) ease-(--ease-smooth-out) hover:scale-110 focus-visible:ring-2 focus-visible:ring-ring/70" })]
}));
Slider.displayName = Slider$1.displayName;
var BACKGROUND_IDS = [
	"void",
	"ink",
	"graphite",
	"dusk",
	"paper"
];
var PALETTE_IDS = [
	"aurora",
	"ember",
	"ice",
	"prism"
];
var BACKGROUNDS = {
	void: {
		id: "void",
		label: "Void",
		rgb: [
			6,
			7,
			9
		],
		swatchClass: "bg-field-void"
	},
	ink: {
		id: "ink",
		label: "Ink",
		rgb: [
			8,
			14,
			24
		],
		swatchClass: "bg-field-ink"
	},
	graphite: {
		id: "graphite",
		label: "Graphite",
		rgb: [
			22,
			22,
			25
		],
		swatchClass: "bg-field-graphite"
	},
	dusk: {
		id: "dusk",
		label: "Dusk",
		rgb: [
			10,
			16,
			14
		],
		swatchClass: "bg-field-dusk"
	},
	paper: {
		id: "paper",
		label: "Paper",
		rgb: [
			230,
			225,
			214
		],
		swatchClass: "bg-field-paper"
	}
};
var PALETTES = {
	aurora: {
		id: "aurora",
		label: "Aurora",
		swatchClass: "bg-swatch-aurora"
	},
	ember: {
		id: "ember",
		label: "Ember",
		swatchClass: "bg-swatch-ember"
	},
	ice: {
		id: "ice",
		label: "Ice",
		swatchClass: "bg-swatch-ice"
	},
	prism: {
		id: "prism",
		label: "Prism",
		swatchClass: "bg-swatch-prism"
	}
};
var COUNT_MAX = 5e3;
var FORCE_MIN = .2;
var FORCE_MAX = 2.4;
var FORCE_STEP = .05;
var TRAIL_STEP = .01;
var DEFAULT_SETTINGS = {
	count: 2200,
	force: 1,
	trail: .78,
	background: "void",
	palette: "aurora"
};
var STORAGE_KEY = "vortex-field-v1";
function isBackground(value) {
	return BACKGROUND_IDS.includes(value);
}
function isPalette(value) {
	return PALETTE_IDS.includes(value);
}
function loadSettings() {
	const fallback = { ...DEFAULT_SETTINGS };
	if (typeof window === "undefined") return fallback;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return fallback;
		const parsed = JSON.parse(raw);
		return {
			count: clampNum(parsed.count, DEFAULT_SETTINGS.count, 400, 5e3),
			force: clampNum(parsed.force, DEFAULT_SETTINGS.force, .2, 2.4),
			trail: clampNum(parsed.trail, DEFAULT_SETTINGS.trail, 0, 1),
			background: isBackground(parsed.background) ? parsed.background : DEFAULT_SETTINGS.background,
			palette: isPalette(parsed.palette) ? parsed.palette : DEFAULT_SETTINGS.palette
		};
	} catch {
		return fallback;
	}
}
function clampNum(value, fallback, min, max) {
	const n = typeof value === "number" ? value : Number(value);
	if (!Number.isFinite(n)) return fallback;
	return Math.min(max, Math.max(min, n));
}
function persist(settings) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
	} catch {}
}
function snapshot(state) {
	return {
		count: state.count,
		force: state.force,
		trail: state.trail,
		background: state.background,
		palette: state.palette
	};
}
function patch(set, get, partial) {
	set(partial);
	const next = snapshot(get());
	persist(next);
	get().engine?.setSettings(next);
}
var useFieldStore = create((set, get) => ({
	...DEFAULT_SETTINGS,
	engine: null,
	bindEngine: (engine) => {
		set({ engine });
		if (engine) engine.setSettings(snapshot(get()));
	},
	setCount: (count) => patch(set, get, { count }),
	setForce: (force) => patch(set, get, { force }),
	setTrail: (trail) => patch(set, get, { trail }),
	setBackground: (background) => patch(set, get, { background }),
	setPalette: (palette) => patch(set, get, { palette }),
	clearTrails: () => get().engine?.clearTrails(),
	resetField: () => get().engine?.resetParticles(),
	resetDefaults: () => {
		persist(DEFAULT_SETTINGS);
		set({ ...DEFAULT_SETTINGS });
		const engine = get().engine;
		engine?.setSettings(DEFAULT_SETTINGS);
		engine?.resetParticles();
	},
	download: () => get().engine?.download()
}));
function hydrateFieldStore() {
	if (typeof window === "undefined") return;
	const loaded = loadSettings();
	useFieldStore.setState(loaded);
	useFieldStore.getState().engine?.setSettings(loaded);
}
function ControlDock() {
	const count = useFieldStore((s) => s.count);
	const force = useFieldStore((s) => s.force);
	const trail = useFieldStore((s) => s.trail);
	const background = useFieldStore((s) => s.background);
	const palette = useFieldStore((s) => s.palette);
	const setCount = useFieldStore((s) => s.setCount);
	const setForce = useFieldStore((s) => s.setForce);
	const setTrail = useFieldStore((s) => s.setTrail);
	const setBackground = useFieldStore((s) => s.setBackground);
	const setPalette = useFieldStore((s) => s.setPalette);
	const clearTrails = useFieldStore((s) => s.clearTrails);
	const resetField = useFieldStore((s) => s.resetField);
	const resetDefaults = useFieldStore((s) => s.resetDefaults);
	const download = useFieldStore((s) => s.download);
	const [hint, setHint] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		hydrateFieldStore();
	}, []);
	(0, import_react.useEffect)(() => {
		const hide = () => setHint(false);
		window.addEventListener("pointerdown", hide, { once: true });
		const t = window.setTimeout(hide, 5200);
		return () => {
			window.removeEventListener("pointerdown", hide);
			window.clearTimeout(t);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "absolute top-0 left-0 p-4 pt-[max(1rem,env(safe-area-inset-top))] pl-[max(1rem,env(safe-area-inset-left))] md:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl font-semibold tracking-tight text-fg text-balance md:text-2xl",
						children: "Vortex"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 max-w-56 text-xs text-muted",
						children: "A living particle field"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-2 text-xs text-subtle md:hidden", "transition-opacity duration-500 ease-out", hint ? "opacity-100" : "opacity-0"),
						children: "Move to stir · Hold to pull"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("absolute top-5 left-1/2 hidden -translate-x-1/2 text-center md:block", "transition-[opacity,transform] duration-500 ease-out", hint ? "opacity-100" : "pointer-events-none translate-y-1 opacity-0"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-full bg-surface/80 px-3 py-1.5 text-xs text-muted shadow-[var(--shadow-border)]",
					children: "Move to stir · Hold to pull"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				"data-dock": true,
				className: cn("pointer-events-auto absolute right-0 bottom-0 left-0", "p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))]", "md:right-auto md:bottom-6 md:left-6 md:w-96 md:p-0"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface/95 p-3 shadow-[var(--shadow-border),0_16px_40px_-24px_rgb(0_0_0_/_0.6)] md:rounded-2xl md:p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center gap-1.5 md:mb-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "secondary",
									size: "sm",
									className: "min-h-11 flex-1 md:min-h-9",
									onClick: clearTrails,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {}), "Clear"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "secondary",
									size: "sm",
									className: "min-h-11 flex-1 md:min-h-9",
									onClick: resetField,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Reset"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "default",
									size: "sm",
									className: "min-h-11 flex-1 md:min-h-9",
									onClick: download,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Save"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-x-3 gap-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
									label: "Particles",
									valueLabel: String(Math.round(count)),
									value: count,
									min: 400,
									max: COUNT_MAX,
									step: 50,
									onChange: setCount
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
									label: "Force",
									valueLabel: `${force.toFixed(2)}×`,
									value: force,
									min: FORCE_MIN,
									max: FORCE_MAX,
									step: FORCE_STEP,
									onChange: setForce
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "col-span-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderField, {
										label: "Trails",
										valueLabel: trailLabel(trail),
										value: trail,
										min: 0,
										max: 1,
										step: TRAIL_STEP,
										onChange: setTrail
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex items-end justify-between gap-4 md:mt-4 md:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-2 text-xs font-medium text-muted",
									children: "Background"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-2",
									children: BACKGROUND_IDS.map((id) => {
										const item = BACKGROUNDS[id];
										const selected = background === id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setBackground(id),
											"aria-label": item.label,
											"aria-pressed": selected,
											title: item.label,
											className: cn("relative size-9 rounded-md transition-[box-shadow,transform] duration-150 ease-out after:absolute after:top-1/2 after:left-1/2 after:size-11 after:-translate-x-1/2 after:-translate-y-1/2 active:scale-[0.96] md:size-11 md:after:content-none", item.swatchClass, selected ? "ring-2 ring-primary ring-offset-2 ring-offset-surface" : "shadow-[var(--shadow-border)] hover:ring-1 hover:ring-fg/30")
										}, id);
									})
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 md:mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs font-medium text-muted",
								children: "Palette"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-4 gap-1.5",
								children: PALETTE_IDS.map((id) => {
									const item = PALETTES[id];
									const selected = palette === id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setPalette(id),
										"aria-pressed": selected,
										className: cn("flex h-11 min-h-11 flex-col items-center justify-center gap-1 rounded-md text-xs font-medium transition-[background-color,color] duration-150 ease-out active:scale-[0.96] md:h-9 md:min-h-9", selected ? "bg-primary text-primary-foreground" : "bg-surface-2 text-muted hover:text-fg"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("size-2 rounded-full", item.swatchClass),
											"aria-hidden": "true"
										}), item.label]
									}, id);
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "sm",
							motion: "none",
							className: "mt-1 h-auto px-0 text-xs text-subtle hover:bg-transparent hover:text-muted md:mt-2",
							onClick: resetDefaults,
							children: "Restore defaults"
						})
					]
				})
			})
		]
	});
}
function trailLabel(trail) {
	if (trail < .2) return "Off";
	if (trail < .5) return "Short";
	if (trail < .8) return "Long";
	return "Ghost";
}
function SliderField({ label, valueLabel, value, min, max, step, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-xs tabular-nums text-fg",
			children: valueLabel
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
		min,
		max,
		step,
		value: [value],
		onValueChange: (v) => {
			const next = v[0];
			if (typeof next === "number") onChange(next);
		},
		"aria-label": label
	})] });
}
var TAU = Math.PI * 2;
var GOLDEN_ANGLE = Math.PI * (3 - Math.sqrt(5));
function hslToRgb(h, s, l) {
	const sat = s / 100;
	const light = l / 100;
	const a = sat * Math.min(light, 1 - light);
	const f = (n) => {
		const k = (n + h / 30) % 12;
		return light - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
	};
	return [
		Math.round(f(0) * 255),
		Math.round(f(8) * 255),
		Math.round(f(4) * 255)
	];
}
var ParticleEngine = class {
	canvas;
	ctx;
	raf = 0;
	running = false;
	width = 1;
	height = 1;
	dpr = 1;
	lastTime = 0;
	time = 0;
	needsHardClear = true;
	count = 0;
	x = /* @__PURE__ */ new Float32Array(0);
	y = /* @__PURE__ */ new Float32Array(0);
	vx = /* @__PURE__ */ new Float32Array(0);
	vy = /* @__PURE__ */ new Float32Array(0);
	hue = /* @__PURE__ */ new Float32Array(0);
	size = /* @__PURE__ */ new Float32Array(0);
	phase = /* @__PURE__ */ new Float32Array(0);
	settings = { ...DEFAULT_SETTINGS };
	reducedMotion = false;
	pointerX = 0;
	pointerY = 0;
	pointerVx = 0;
	pointerVy = 0;
	hasPointer = false;
	pointerDown = false;
	idleX = 0;
	idleY = 0;
	rings = [];
	observer = null;
	onPointerMove = (e) => {
		if (e.target?.closest("[data-dock]")) return;
		const rect = this.canvas.getBoundingClientRect();
		const nx = e.clientX - rect.left;
		const ny = e.clientY - rect.top;
		this.pointerVx = nx - this.pointerX;
		this.pointerVy = ny - this.pointerY;
		this.pointerX = nx;
		this.pointerY = ny;
		this.hasPointer = true;
	};
	onPointerDown = (e) => {
		if (e.button !== 0 && e.pointerType === "mouse") return;
		e.preventDefault();
		this.canvas.setPointerCapture(e.pointerId);
		this.onPointerMove(e);
		this.pointerDown = true;
		this.burst(this.pointerX, this.pointerY);
	};
	onPointerUp = (e) => {
		this.pointerDown = false;
		if (this.canvas.hasPointerCapture(e.pointerId)) this.canvas.releasePointerCapture(e.pointerId);
	};
	onBlur = () => {
		this.pointerDown = false;
	};
	constructor(canvas) {
		this.canvas = canvas;
		const ctx = canvas.getContext("2d", {
			alpha: false,
			desynchronized: true
		});
		if (!ctx) throw new Error("Canvas 2D is not available.");
		this.ctx = ctx;
		this.reducedMotion = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
		this.resize();
		this.pointerX = this.width * .5;
		this.pointerY = this.height * .5;
		this.idleX = this.pointerX;
		this.idleY = this.pointerY;
		this.rebuild(this.settings.count);
	}
	setSettings(next) {
		const prevBg = this.settings.background;
		const prevCount = this.settings.count;
		this.settings = {
			...this.settings,
			...next
		};
		if (this.settings.count !== prevCount) this.rebuild(this.settings.count);
		if (this.settings.background !== prevBg) this.needsHardClear = true;
	}
	getSettings() {
		return this.settings;
	}
	start() {
		if (this.running) return;
		this.running = true;
		this.lastTime = 0;
		this.observer = new ResizeObserver(() => this.resize());
		this.observer.observe(this.canvas.parentElement ?? this.canvas);
		window.addEventListener("pointermove", this.onPointerMove, { passive: true });
		this.canvas.addEventListener("pointerdown", this.onPointerDown);
		window.addEventListener("pointerup", this.onPointerUp);
		window.addEventListener("pointercancel", this.onPointerUp);
		window.addEventListener("blur", this.onBlur);
		this.raf = requestAnimationFrame(this.frame);
	}
	destroy() {
		this.running = false;
		cancelAnimationFrame(this.raf);
		this.observer?.disconnect();
		this.observer = null;
		window.removeEventListener("pointermove", this.onPointerMove);
		this.canvas.removeEventListener("pointerdown", this.onPointerDown);
		window.removeEventListener("pointerup", this.onPointerUp);
		window.removeEventListener("pointercancel", this.onPointerUp);
		window.removeEventListener("blur", this.onBlur);
	}
	clearTrails() {
		this.needsHardClear = true;
	}
	resetParticles() {
		this.rebuild(this.settings.count);
		this.needsHardClear = true;
	}
	download() {
		this.canvas.toBlob((blob) => {
			if (!blob) return;
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = `vortex-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.png`;
			document.body.appendChild(a);
			a.click();
			a.remove();
			URL.revokeObjectURL(url);
		}, "image/png");
	}
	resize() {
		const rect = (this.canvas.parentElement ?? this.canvas).getBoundingClientRect();
		const cssW = Math.max(1, Math.floor(rect.width));
		const cssH = Math.max(1, Math.floor(rect.height));
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		this.dpr = dpr;
		this.width = cssW;
		this.height = cssH;
		this.canvas.width = Math.floor(cssW * dpr);
		this.canvas.height = Math.floor(cssH * dpr);
		this.canvas.style.width = `${cssW}px`;
		this.canvas.style.height = `${cssH}px`;
		this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		this.needsHardClear = true;
		if (!this.hasPointer) {
			this.pointerX = cssW * .5;
			this.pointerY = cssH * .5;
			this.idleX = this.pointerX;
			this.idleY = this.pointerY;
		}
	}
	rebuild(n) {
		const next = Math.max(1, Math.floor(n));
		const prev = this.count;
		const x = new Float32Array(next);
		const y = new Float32Array(next);
		const vx = new Float32Array(next);
		const vy = new Float32Array(next);
		const hue = new Float32Array(next);
		const size = new Float32Array(next);
		const phase = new Float32Array(next);
		const keep = Math.min(prev, next);
		if (keep > 0) {
			x.set(this.x.subarray(0, keep));
			y.set(this.y.subarray(0, keep));
			vx.set(this.vx.subarray(0, keep));
			vy.set(this.vy.subarray(0, keep));
			hue.set(this.hue.subarray(0, keep));
			size.set(this.size.subarray(0, keep));
			phase.set(this.phase.subarray(0, keep));
		}
		this.x = x;
		this.y = y;
		this.vx = vx;
		this.vy = vy;
		this.hue = hue;
		this.size = size;
		this.phase = phase;
		this.count = next;
		if (keep === 0) this.seedAll();
		else for (let i = keep; i < next; i++) this.seedOne(i);
	}
	seedAll() {
		for (let i = 0; i < this.count; i++) this.seedOne(i, true);
	}
	seedOne(i, formation = false) {
		const cx = this.width * .5;
		const cy = this.height * .5;
		const radius = Math.min(this.width, this.height) * .42;
		if (formation) {
			const t = (i + .5) / this.count;
			const r = Math.sqrt(t) * radius;
			const a = i * GOLDEN_ANGLE;
			this.x[i] = cx + Math.cos(a) * r;
			this.y[i] = cy + Math.sin(a) * r;
			const spin = 46 + t * 38;
			this.vx[i] = -Math.sin(a) * spin;
			this.vy[i] = Math.cos(a) * spin;
		} else {
			const a = Math.random() * TAU;
			const r = Math.sqrt(Math.random()) * radius;
			this.x[i] = cx + Math.cos(a) * r;
			this.y[i] = cy + Math.sin(a) * r;
			this.vx[i] = (Math.random() - .5) * 40;
			this.vy[i] = (Math.random() - .5) * 40;
		}
		this.hue[i] = Math.random() * 360;
		this.size[i] = i % 11 === 0 ? 2.4 + Math.random() * 1.4 : .9 + Math.random() * 1.2;
		this.phase[i] = Math.random() * TAU;
	}
	burst(px, py) {
		const radius = 240;
		const x = this.x;
		const y = this.y;
		const vx = this.vx;
		const vy = this.vy;
		const kick = 180 + this.settings.force * 90;
		for (let i = 0; i < this.count; i++) {
			const dx = x[i] - px;
			const dy = y[i] - py;
			const d = Math.hypot(dx, dy) || 1;
			if (d > radius) continue;
			const k = (1 - d / radius) * kick;
			const nx = dx / d;
			const ny = dy / d;
			vx[i] += nx * k * .55 + -ny * k;
			vy[i] += ny * k * .55 + nx * k;
		}
		this.rings.push({
			x: px,
			y: py,
			r: 8,
			vr: 280,
			life: .55,
			maxLife: .55
		}, {
			x: px,
			y: py,
			r: 4,
			vr: 160,
			life: .38,
			maxLife: .38
		});
		if (this.rings.length > 8) this.rings.splice(0, this.rings.length - 8);
	}
	frame = (now) => {
		if (!this.running) return;
		const t = now * .001;
		let dt = this.lastTime === 0 ? 1 / 60 : t - this.lastTime;
		this.lastTime = t;
		if (dt > .1) dt = .1;
		this.time += dt;
		this.step(dt);
		this.draw();
		this.pointerVx *= .72;
		this.pointerVy *= .72;
		this.raf = requestAnimationFrame(this.frame);
	};
	attractor(dt) {
		if (this.hasPointer) return {
			ax: this.pointerX,
			ay: this.pointerY
		};
		const t = this.time;
		const cx = this.width * .5;
		const cy = this.height * .5;
		const orbit = Math.min(this.width, this.height) * .16;
		const targetX = cx + Math.cos(t * .23) * orbit;
		const targetY = cy + Math.sin(t * .19) * orbit * .72;
		const k = 1 - Math.exp(-2.4 * dt);
		this.idleX += (targetX - this.idleX) * k;
		this.idleY += (targetY - this.idleY) * k;
		return {
			ax: this.idleX,
			ay: this.idleY
		};
	}
	step(dt) {
		const { force, palette } = this.settings;
		const { ax: tx, ay: ty } = this.attractor(dt);
		const hold = this.pointerDown;
		const motion = this.reducedMotion ? .5 : 1;
		const pull = (hold ? 5600 : 2680) * force * motion;
		const swirl = (hold ? 980 : 3120) * force * motion;
		const damp = Math.exp(-(hold ? 3.6 : 1.55) * dt);
		const minD = hold ? 18 : 32;
		const time = this.time;
		const w = this.width;
		const h = this.height;
		const x = this.x;
		const y = this.y;
		const vx = this.vx;
		const vy = this.vy;
		const hue = this.hue;
		const phase = this.phase;
		const n = this.count;
		const pvx = this.pointerVx;
		const pvy = this.pointerVy;
		for (let i = 0; i < n; i++) {
			let px = x[i];
			let py = y[i];
			const dx = tx - px;
			const dy = ty - py;
			const dist = Math.hypot(dx, dy) || 1;
			const inv = 1 / Math.max(dist, minD);
			const nx = dx * inv;
			const ny = dy * inv;
			const falloff = 110 * inv;
			const aPull = pull * falloff;
			const aSwirl = swirl * falloff;
			let avx = vx[i] + (nx * aPull + -ny * aSwirl) * dt;
			let avy = vy[i] + (ny * aPull + nx * aSwirl) * dt;
			const ph = phase[i] + time;
			avx += Math.sin(ph * 1.7 + px * .012) * 18 * dt;
			avy += Math.cos(ph * 1.3 + py * .012) * 18 * dt;
			const near = Math.max(0, 1 - dist / 160);
			avx += pvx * near * 2.6;
			avy += pvy * near * 2.6;
			avx *= damp;
			avy *= damp;
			const spd = Math.hypot(avx, avy);
			const maxSpd = 1480 * force;
			if (spd > maxSpd) {
				const s = maxSpd / spd;
				avx *= s;
				avy *= s;
			}
			px += avx * dt;
			py += avy * dt;
			const m = 48;
			if (px < -48) px = w + m;
			else if (px > w + m) px = -48;
			if (py < -48) py = h + m;
			else if (py > h + m) py = -48;
			x[i] = px;
			y[i] = py;
			vx[i] = avx;
			vy[i] = avy;
			if (palette === "prism") hue[i] = (Math.atan2(dy, dx) * 180 / Math.PI + 180 + time * 28 + phase[i] * 12) % 360;
		}
		for (let i = this.rings.length - 1; i >= 0; i--) {
			const ring = this.rings[i];
			ring.life -= dt;
			ring.r += ring.vr * dt;
			if (ring.life <= 0) this.rings.splice(i, 1);
		}
	}
	particleColor(i, speed, dist) {
		const palette = this.settings.palette;
		const paper = this.settings.background === "paper";
		const t = this.time;
		const spark = i % 11 === 0;
		let h = this.hue[i];
		let s = 62;
		let l = 58;
		const speedN = Math.min(speed / 420, 1);
		const near = Math.max(0, 1 - dist / 280);
		if (palette === "aurora") {
			h = 168 + Math.sin(this.phase[i] + t * .35) * 26 + speedN * 18;
			s = 58 + near * 18;
			l = 52 + speedN * 22 + (spark ? 10 : 0);
		} else if (palette === "ember") {
			h = 22 + Math.sin(this.phase[i] * 2 + t * .4) * 14 + speedN * 10;
			s = 72 + near * 12;
			l = 50 + speedN * 18 + (spark ? 8 : 0);
		} else if (palette === "ice") {
			h = 204 + Math.sin(this.phase[i] + t * .2) * 10;
			s = 28 + speedN * 22 + near * 10;
			l = 72 + speedN * 14 + (spark ? 8 : 0);
		} else {
			s = 64 + near * 16;
			l = 54 + speedN * 20 + (spark ? 8 : 0);
		}
		if (paper) {
			s = Math.min(s + 8, 86);
			l = Math.min(Math.max(l - 18, 28), 48);
		}
		const [r, g, b] = hslToRgb(h, s, l);
		const alpha = paper ? .55 + speedN * .35 : .42 + speedN * .45 + (spark ? .12 : 0);
		return [
			r,
			g,
			b,
			Math.min(alpha, .95)
		];
	}
	draw() {
		const ctx = this.ctx;
		const w = this.width;
		const h = this.height;
		const [br, bgc, bb] = BACKGROUNDS[this.settings.background].rgb;
		const additive = this.settings.background !== "paper";
		const trail = this.reducedMotion ? this.settings.trail * .45 : this.settings.trail;
		const fade = this.needsHardClear ? 1 : .22 * (1 - trail) + .028;
		ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
		ctx.globalCompositeOperation = "source-over";
		ctx.fillStyle = `rgba(${br},${bgc},${bb},${fade})`;
		ctx.fillRect(0, 0, w, h);
		this.needsHardClear = false;
		const { ax, ay } = this.hasPointer ? {
			ax: this.pointerX,
			ay: this.pointerY
		} : {
			ax: this.idleX,
			ay: this.idleY
		};
		this.drawWell(ctx, ax, ay, additive);
		if (additive) ctx.globalCompositeOperation = "lighter";
		const x = this.x;
		const y = this.y;
		const vx = this.vx;
		const vy = this.vy;
		const size = this.size;
		const n = this.count;
		const skipGlow = n > 3200;
		for (let i = 0; i < n; i++) {
			const px = x[i];
			const py = y[i];
			const avx = vx[i];
			const avy = vy[i];
			const speed = Math.hypot(avx, avy);
			const dist = Math.hypot(ax - px, ay - py);
			const [r, g, b, a] = this.particleColor(i, speed, dist);
			const rad = size[i] * (1 + Math.min(speed * .0024, 1.1));
			const stretch = 1 + Math.min(speed * .016, 3.4);
			const ang = Math.atan2(avy, avx);
			const rx = rad * stretch;
			const ry = rad / Math.sqrt(stretch);
			ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
			ctx.beginPath();
			ctx.ellipse(px, py, rx, ry, ang, 0, TAU);
			ctx.fill();
			if (!skipGlow && i % 3 === 0) {
				ctx.fillStyle = `rgba(${r},${g},${b},${a * .22})`;
				ctx.beginPath();
				ctx.ellipse(px, py, rx * 2.1, ry * 2.1, ang, 0, TAU);
				ctx.fill();
			}
		}
		this.drawRings(ctx, additive);
		ctx.globalCompositeOperation = "source-over";
	}
	drawWell(ctx, ax, ay, additive) {
		const hold = this.pointerDown;
		const radius = hold ? 26 : 38;
		const pulse = .82 + Math.sin(this.time * 3.2) * .08;
		const grad = ctx.createRadialGradient(ax, ay, 0, ax, ay, radius * 4.2 * pulse);
		if (additive) {
			grad.addColorStop(0, "rgba(210, 236, 236, 0.28)");
			grad.addColorStop(.22, "rgba(142, 200, 201, 0.12)");
			grad.addColorStop(1, "rgba(142, 200, 201, 0)");
		} else {
			grad.addColorStop(0, "rgba(40, 48, 52, 0.22)");
			grad.addColorStop(1, "rgba(40, 48, 52, 0)");
		}
		ctx.globalCompositeOperation = additive ? "lighter" : "source-over";
		ctx.fillStyle = grad;
		ctx.beginPath();
		ctx.arc(ax, ay, radius * 4.2 * pulse, 0, TAU);
		ctx.fill();
		ctx.globalCompositeOperation = "source-over";
		ctx.strokeStyle = hold ? "rgba(236, 236, 232, 0.85)" : "rgba(236, 236, 232, 0.45)";
		ctx.lineWidth = 1.25;
		ctx.beginPath();
		ctx.arc(ax, ay, hold ? 10 : 14, 0, TAU);
		ctx.stroke();
		ctx.fillStyle = "rgba(236, 236, 232, 0.92)";
		ctx.beginPath();
		ctx.arc(ax, ay, 2.2, 0, TAU);
		ctx.fill();
	}
	drawRings(ctx, additive) {
		for (const ring of this.rings) {
			const t = ring.life / ring.maxLife;
			ctx.strokeStyle = `rgba(220, 232, 232, ${t * (additive ? .55 : .35)})`;
			ctx.lineWidth = 1.5 * t + .4;
			ctx.beginPath();
			ctx.arc(ring.x, ring.y, ring.r, 0, TAU);
			ctx.stroke();
		}
	}
};
function FieldCanvas() {
	const canvasRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const engine = new ParticleEngine(canvas);
		useFieldStore.getState().bindEngine(engine);
		engine.start();
		return () => {
			engine.destroy();
			useFieldStore.getState().bindEngine(null);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvasRef,
		className: "absolute inset-0 size-full cursor-none touch-none",
		"aria-label": "Interactive particle field. Move to stir particles, hold to pull them in."
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh overflow-hidden bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldCanvas, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlDock, {})]
	});
}
//#endregion
export { Home as component };
