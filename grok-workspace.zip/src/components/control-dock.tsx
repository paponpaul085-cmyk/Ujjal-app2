import { useEffect, useState } from "react";
import { Download, Eraser, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  BACKGROUNDS,
  BACKGROUND_IDS,
  COUNT_MAX,
  COUNT_MIN,
  COUNT_STEP,
  FORCE_MAX,
  FORCE_MIN,
  FORCE_STEP,
  PALETTES,
  PALETTE_IDS,
  TRAIL_MAX,
  TRAIL_MIN,
  TRAIL_STEP,
} from "@/lib/field-config";
import { hydrateFieldStore, useFieldStore } from "@/lib/field-store";
import { cn } from "@/lib/utils";

export function ControlDock() {
  const count = useFieldStore((s) => s.count);
  const force = useFieldStore((s) => s.force);
  const trail = useFieldStore((s) => s.trail);
  const background = useFieldStore((s) => s.background);
  const palette = useFieldStore((s) => s.palette);
  const setCount = useFieldStore((s) => s.setCount);
  const setForce = useFieldStore((s) => s.setForce);
  const setTrail = useFieldStore((s) => s.setTrail);
  const setBackground = useFieldStore((s) => s.setBackground);
  const setPalette = useFieldStore((s) => s.setPalette);
  const clearTrails = useFieldStore((s) => s.clearTrails);
  const resetField = useFieldStore((s) => s.resetField);
  const resetDefaults = useFieldStore((s) => s.resetDefaults);
  const download = useFieldStore((s) => s.download);

  const [hint, setHint] = useState(true);

  useEffect(() => {
    hydrateFieldStore();
  }, []);

  useEffect(() => {
    const hide = () => setHint(false);
    window.addEventListener("pointerdown", hide, { once: true });
    const t = window.setTimeout(hide, 5200);
    return () => {
      window.removeEventListener("pointerdown", hide);
      window.clearTimeout(t);
    };
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 z-10">
      <header className="absolute top-0 left-0 p-4 pt-[max(1rem,env(safe-area-inset-top))] pl-[max(1rem,env(safe-area-inset-left))] md:p-6">
        <p className="font-display text-xl font-semibold tracking-tight text-fg text-balance md:text-2xl">
          Vortex
        </p>
        <p className="mt-0.5 max-w-56 text-xs text-muted">A living particle field</p>
        <p
          className={cn(
            "mt-2 text-xs text-subtle md:hidden",
            "transition-opacity duration-500 ease-out",
            hint ? "opacity-100" : "opacity-0",
          )}
        >
          Move to stir · Hold to pull
        </p>
      </header>

      <div
        className={cn(
          "absolute top-5 left-1/2 hidden -translate-x-1/2 text-center md:block",
          "transition-[opacity,transform] duration-500 ease-out",
          hint ? "opacity-100" : "pointer-events-none translate-y-1 opacity-0",
        )}
      >
        <p className="rounded-full bg-surface/80 px-3 py-1.5 text-xs text-muted shadow-[var(--shadow-border)]">
          Move to stir · Hold to pull
        </p>
      </div>

      <section
        data-dock
        className={cn(
          "pointer-events-auto absolute right-0 bottom-0 left-0",
          "p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pl-[max(0.75rem,env(safe-area-inset-left))] pr-[max(0.75rem,env(safe-area-inset-right))]",
          "md:right-auto md:bottom-6 md:left-6 md:w-96 md:p-0",
        )}
      >
        <div className="rounded-xl bg-surface/95 p-3 shadow-[var(--shadow-border),0_16px_40px_-24px_rgb(0_0_0_/_0.6)] md:rounded-2xl md:p-4">
          <div className="mb-2 flex items-center gap-1.5 md:mb-4">
            <Button
              type="button"
              variant="secondary"
              size="sm"
              className="min-h-11 flex-1 md:min-h-9"
              onClick={clearTrails}
            >
              <Eraser />
              Clear
            </Button>
            <Button
              type="button"
              variant="secondary"
              size="sm"
              className="min-h-11 flex-1 md:min-h-9"
              onClick={resetField}
            >
              <RotateCcw />
              Reset
            </Button>
            <Button
              type="button"
              variant="default"
              size="sm"
              className="min-h-11 flex-1 md:min-h-9"
              onClick={download}
            >
              <Download />
              Save
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-x-3 gap-y-1">
            <SliderField
              label="Particles"
              valueLabel={String(Math.round(count))}
              value={count}
              min={COUNT_MIN}
              max={COUNT_MAX}
              step={COUNT_STEP}
              onChange={setCount}
            />
            <SliderField
              label="Force"
              valueLabel={`${force.toFixed(2)}×`}
              value={force}
              min={FORCE_MIN}
              max={FORCE_MAX}
              step={FORCE_STEP}
              onChange={setForce}
            />
            <div className="col-span-2">
              <SliderField
                label="Trails"
                valueLabel={trailLabel(trail)}
                value={trail}
                min={TRAIL_MIN}
                max={TRAIL_MAX}
                step={TRAIL_STEP}
                onChange={setTrail}
              />
            </div>
          </div>

          <div className="mt-2 flex items-end justify-between gap-4 md:mt-4 md:block">
            <div className="min-w-0">
              <p className="mb-2 text-xs font-medium text-muted">Background</p>
              <div className="flex flex-wrap gap-2">
                {BACKGROUND_IDS.map((id) => {
                  const item = BACKGROUNDS[id];
                  const selected = background === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setBackground(id)}
                      aria-label={item.label}
                      aria-pressed={selected}
                      title={item.label}
                      className={cn(
                        "relative size-9 rounded-md transition-[box-shadow,transform] duration-150 ease-out after:absolute after:top-1/2 after:left-1/2 after:size-11 after:-translate-x-1/2 after:-translate-y-1/2 active:scale-[0.96] md:size-11 md:after:content-none",
                        item.swatchClass,
                        selected
                          ? "ring-2 ring-primary ring-offset-2 ring-offset-surface"
                          : "shadow-[var(--shadow-border)] hover:ring-1 hover:ring-fg/30",
                      )}
                    />
                  );
                })}
              </div>
            </div>
          </div>

          <div className="mt-2 md:mt-4">
            <p className="mb-2 text-xs font-medium text-muted">Palette</p>
            <div className="grid grid-cols-4 gap-1.5">
              {PALETTE_IDS.map((id) => {
                const item = PALETTES[id];
                const selected = palette === id;
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setPalette(id)}
                    aria-pressed={selected}
                    className={cn(
                      "flex h-11 min-h-11 flex-col items-center justify-center gap-1 rounded-md text-xs font-medium transition-[background-color,color] duration-150 ease-out active:scale-[0.96] md:h-9 md:min-h-9",
                      selected
                        ? "bg-primary text-primary-foreground"
                        : "bg-surface-2 text-muted hover:text-fg",
                    )}
                  >
                    <span
                      className={cn("size-2 rounded-full", item.swatchClass)}
                      aria-hidden="true"
                    />
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>

          <Button
            type="button"
            variant="ghost"
            size="sm"
            motion="none"
            className="mt-1 h-auto px-0 text-xs text-subtle hover:bg-transparent hover:text-muted md:mt-2"
            onClick={resetDefaults}
          >
            Restore defaults
          </Button>
        </div>
      </section>
    </div>
  );
}

function trailLabel(trail: number) {
  if (trail < 0.2) return "Off";
  if (trail < 0.5) return "Short";
  if (trail < 0.8) return "Long";
  return "Ghost";
}

function SliderField({
  label,
  valueLabel,
  value,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  valueLabel: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (value: number) => void;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs font-medium text-muted">{label}</span>
        <span className="font-mono text-xs tabular-nums text-fg">{valueLabel}</span>
      </div>
      <Slider
        min={min}
        max={max}
        step={step}
        value={[value]}
        onValueChange={(v) => {
          const next = v[0];
          if (typeof next === "number") onChange(next);
        }}
        aria-label={label}
      />
    </div>
  );
}
