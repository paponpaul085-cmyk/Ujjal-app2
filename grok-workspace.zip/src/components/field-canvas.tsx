import { useEffect, useRef } from "react";
import { ParticleEngine } from "@/lib/particle-engine";
import { useFieldStore } from "@/lib/field-store";

export function FieldCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new ParticleEngine(canvas);
    useFieldStore.getState().bindEngine(engine);
    engine.start();
    return () => {
      engine.destroy();
      useFieldStore.getState().bindEngine(null);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 size-full cursor-none touch-none"
      aria-label="Interactive particle field. Move to stir particles, hold to pull them in."
    />
  );
}
