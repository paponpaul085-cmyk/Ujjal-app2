export const BACKGROUND_IDS = ["void", "ink", "graphite", "dusk", "paper"] as const;
export type BackgroundId = (typeof BACKGROUND_IDS)[number];

export const PALETTE_IDS = ["aurora", "ember", "ice", "prism"] as const;
export type PaletteId = (typeof PALETTE_IDS)[number];

export type Background = {
  id: BackgroundId;
  label: string;
  rgb: readonly [number, number, number];
  swatchClass: string;
};

export type Palette = {
  id: PaletteId;
  label: string;
  swatchClass: string;
};

export const BACKGROUNDS: Record<BackgroundId, Background> = {
  void: {
    id: "void",
    label: "Void",
    rgb: [6, 7, 9],
    swatchClass: "bg-field-void",
  },
  ink: {
    id: "ink",
    label: "Ink",
    rgb: [8, 14, 24],
    swatchClass: "bg-field-ink",
  },
  graphite: {
    id: "graphite",
    label: "Graphite",
    rgb: [22, 22, 25],
    swatchClass: "bg-field-graphite",
  },
  dusk: {
    id: "dusk",
    label: "Dusk",
    rgb: [10, 16, 14],
    swatchClass: "bg-field-dusk",
  },
  paper: {
    id: "paper",
    label: "Paper",
    rgb: [230, 225, 214],
    swatchClass: "bg-field-paper",
  },
};

export const PALETTES: Record<PaletteId, Palette> = {
  aurora: { id: "aurora", label: "Aurora", swatchClass: "bg-swatch-aurora" },
  ember: { id: "ember", label: "Ember", swatchClass: "bg-swatch-ember" },
  ice: { id: "ice", label: "Ice", swatchClass: "bg-swatch-ice" },
  prism: { id: "prism", label: "Prism", swatchClass: "bg-swatch-prism" },
};

export const COUNT_MIN = 400;
export const COUNT_MAX = 5000;
export const COUNT_STEP = 50;
export const FORCE_MIN = 0.2;
export const FORCE_MAX = 2.4;
export const FORCE_STEP = 0.05;
export const TRAIL_MIN = 0;
export const TRAIL_MAX = 1;
export const TRAIL_STEP = 0.01;

export const DEFAULT_SETTINGS = {
  count: 2200,
  force: 1,
  trail: 0.78,
  background: "void" as BackgroundId,
  palette: "aurora" as PaletteId,
};

export type FieldSettings = {
  count: number;
  force: number;
  trail: number;
  background: BackgroundId;
  palette: PaletteId;
};
