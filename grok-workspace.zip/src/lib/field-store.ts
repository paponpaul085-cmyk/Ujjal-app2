import { create } from "zustand";
import {
  BACKGROUND_IDS,
  DEFAULT_SETTINGS,
  PALETTE_IDS,
  type BackgroundId,
  type FieldSettings,
  type PaletteId,
} from "@/lib/field-config";
import type { ParticleEngine } from "@/lib/particle-engine";

const STORAGE_KEY = "vortex-field-v1";

function isBackground(value: unknown): value is BackgroundId {
  return BACKGROUND_IDS.includes(value as BackgroundId);
}

function isPalette(value: unknown): value is PaletteId {
  return PALETTE_IDS.includes(value as PaletteId);
}

function loadSettings(): FieldSettings {
  const fallback: FieldSettings = { ...DEFAULT_SETTINGS };
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<FieldSettings>;
    return {
      count: clampNum(parsed.count, DEFAULT_SETTINGS.count, 400, 5000),
      force: clampNum(parsed.force, DEFAULT_SETTINGS.force, 0.2, 2.4),
      trail: clampNum(parsed.trail, DEFAULT_SETTINGS.trail, 0, 1),
      background: isBackground(parsed.background)
        ? parsed.background
        : DEFAULT_SETTINGS.background,
      palette: isPalette(parsed.palette) ? parsed.palette : DEFAULT_SETTINGS.palette,
    };
  } catch {
    return fallback;
  }
}

function clampNum(value: unknown, fallback: number, min: number, max: number) {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function persist(settings: FieldSettings) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    /* ignore quota */
  }
}

function snapshot(state: FieldSettings): FieldSettings {
  return {
    count: state.count,
    force: state.force,
    trail: state.trail,
    background: state.background,
    palette: state.palette,
  };
}

type FieldStore = FieldSettings & {
  engine: ParticleEngine | null;
  bindEngine: (engine: ParticleEngine | null) => void;
  setCount: (count: number) => void;
  setForce: (force: number) => void;
  setTrail: (trail: number) => void;
  setBackground: (background: FieldSettings["background"]) => void;
  setPalette: (palette: FieldSettings["palette"]) => void;
  clearTrails: () => void;
  resetField: () => void;
  resetDefaults: () => void;
  download: () => void;
};

function patch(
  set: (partial: Partial<FieldStore>) => void,
  get: () => FieldStore,
  partial: Partial<FieldSettings>,
) {
  set(partial);
  const next = snapshot(get());
  persist(next);
  get().engine?.setSettings(next);
}

export const useFieldStore = create<FieldStore>((set, get) => ({
  ...DEFAULT_SETTINGS,
  engine: null,
  bindEngine: (engine) => {
    set({ engine });
    if (engine) engine.setSettings(snapshot(get()));
  },
  setCount: (count) => patch(set, get, { count }),
  setForce: (force) => patch(set, get, { force }),
  setTrail: (trail) => patch(set, get, { trail }),
  setBackground: (background) => patch(set, get, { background }),
  setPalette: (palette) => patch(set, get, { palette }),
  clearTrails: () => get().engine?.clearTrails(),
  resetField: () => get().engine?.resetParticles(),
  resetDefaults: () => {
    persist(DEFAULT_SETTINGS);
    set({ ...DEFAULT_SETTINGS });
    const engine = get().engine;
    engine?.setSettings(DEFAULT_SETTINGS);
    engine?.resetParticles();
  },
  download: () => get().engine?.download(),
}));

export function hydrateFieldStore() {
  if (typeof window === "undefined") return;
  const loaded = loadSettings();
  useFieldStore.setState(loaded);
  useFieldStore.getState().engine?.setSettings(loaded);
}
