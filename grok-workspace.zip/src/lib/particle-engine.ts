import {
  BACKGROUNDS,
  DEFAULT_SETTINGS,
  type BackgroundId,
  type FieldSettings,
  type PaletteId,
} from "@/lib/field-config";

const TAU = Math.PI * 2;
const GOLDEN_ANGLE = Math.PI * (3 - Math.sqrt(5));

type Ring = {
  x: number;
  y: number;
  r: number;
  vr: number;
  life: number;
  maxLife: number;
};

function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  const sat = s / 100;
  const light = l / 100;
  const a = sat * Math.min(light, 1 - light);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    return light - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
  };
  return [Math.round(f(0) * 255), Math.round(f(8) * 255), Math.round(f(4) * 255)];
}

export class ParticleEngine {
  readonly canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private raf = 0;
  private running = false;
  private width = 1;
  private height = 1;
  private dpr = 1;
  private lastTime = 0;
  private time = 0;
  private needsHardClear = true;

  private count = 0;
  private x = new Float32Array(0);
  private y = new Float32Array(0);
  private vx = new Float32Array(0);
  private vy = new Float32Array(0);
  private hue = new Float32Array(0);
  private size = new Float32Array(0);
  private phase = new Float32Array(0);

  private settings: FieldSettings = { ...DEFAULT_SETTINGS };
  private reducedMotion = false;

  private pointerX = 0;
  private pointerY = 0;
  private pointerVx = 0;
  private pointerVy = 0;
  private hasPointer = false;
  private pointerDown = false;
  private idleX = 0;
  private idleY = 0;

  private rings: Ring[] = [];
  private observer: ResizeObserver | null = null;

  private onPointerMove = (e: PointerEvent) => {
    const target = e.target as HTMLElement | null;
    if (target?.closest("[data-dock]")) return;
    const rect = this.canvas.getBoundingClientRect();
    const nx = e.clientX - rect.left;
    const ny = e.clientY - rect.top;
    this.pointerVx = nx - this.pointerX;
    this.pointerVy = ny - this.pointerY;
    this.pointerX = nx;
    this.pointerY = ny;
    this.hasPointer = true;
  };

  private onPointerDown = (e: PointerEvent) => {
    if (e.button !== 0 && e.pointerType === "mouse") return;
    e.preventDefault();
    this.canvas.setPointerCapture(e.pointerId);
    this.onPointerMove(e);
    this.pointerDown = true;
    this.burst(this.pointerX, this.pointerY);
  };

  private onPointerUp = (e: PointerEvent) => {
    this.pointerDown = false;
    if (this.canvas.hasPointerCapture(e.pointerId)) {
      this.canvas.releasePointerCapture(e.pointerId);
    }
  };

  private onBlur = () => {
    this.pointerDown = false;
  };

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d", { alpha: false, desynchronized: true });
    if (!ctx) throw new Error("Canvas 2D is not available.");
    this.ctx = ctx;
    this.reducedMotion =
      typeof matchMedia === "function" &&
      matchMedia("(prefers-reduced-motion: reduce)").matches;
    this.resize();
    this.pointerX = this.width * 0.5;
    this.pointerY = this.height * 0.5;
    this.idleX = this.pointerX;
    this.idleY = this.pointerY;
    this.rebuild(this.settings.count);
  }

  setSettings(next: Partial<FieldSettings>) {
    const prevBg = this.settings.background;
    const prevCount = this.settings.count;
    this.settings = { ...this.settings, ...next };
    if (this.settings.count !== prevCount) this.rebuild(this.settings.count);
    if (this.settings.background !== prevBg) this.needsHardClear = true;
  }

  getSettings(): FieldSettings {
    return this.settings;
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.lastTime = 0;
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(this.canvas.parentElement ?? this.canvas);
    window.addEventListener("pointermove", this.onPointerMove, { passive: true });
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    window.addEventListener("pointerup", this.onPointerUp);
    window.addEventListener("pointercancel", this.onPointerUp);
    window.addEventListener("blur", this.onBlur);
    this.raf = requestAnimationFrame(this.frame);
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.observer?.disconnect();
    this.observer = null;
    window.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    window.removeEventListener("pointerup", this.onPointerUp);
    window.removeEventListener("pointercancel", this.onPointerUp);
    window.removeEventListener("blur", this.onBlur);
  }

  clearTrails() {
    this.needsHardClear = true;
  }

  resetParticles() {
    this.rebuild(this.settings.count);
    this.needsHardClear = true;
  }

  download() {
    this.canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `vortex-${new Date().toISOString().slice(0, 10)}.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    }, "image/png");
  }

  private resize() {
    const parent = this.canvas.parentElement ?? this.canvas;
    const rect = parent.getBoundingClientRect();
    const cssW = Math.max(1, Math.floor(rect.width));
    const cssH = Math.max(1, Math.floor(rect.height));
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.dpr = dpr;
    this.width = cssW;
    this.height = cssH;
    this.canvas.width = Math.floor(cssW * dpr);
    this.canvas.height = Math.floor(cssH * dpr);
    this.canvas.style.width = `${cssW}px`;
    this.canvas.style.height = `${cssH}px`;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.needsHardClear = true;
    if (!this.hasPointer) {
      this.pointerX = cssW * 0.5;
      this.pointerY = cssH * 0.5;
      this.idleX = this.pointerX;
      this.idleY = this.pointerY;
    }
  }

  private rebuild(n: number) {
    const next = Math.max(1, Math.floor(n));
    const prev = this.count;
    const x = new Float32Array(next);
    const y = new Float32Array(next);
    const vx = new Float32Array(next);
    const vy = new Float32Array(next);
    const hue = new Float32Array(next);
    const size = new Float32Array(next);
    const phase = new Float32Array(next);

    const keep = Math.min(prev, next);
    if (keep > 0) {
      x.set(this.x.subarray(0, keep));
      y.set(this.y.subarray(0, keep));
      vx.set(this.vx.subarray(0, keep));
      vy.set(this.vy.subarray(0, keep));
      hue.set(this.hue.subarray(0, keep));
      size.set(this.size.subarray(0, keep));
      phase.set(this.phase.subarray(0, keep));
    }

    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.hue = hue;
    this.size = size;
    this.phase = phase;
    this.count = next;

    if (keep === 0) this.seedAll();
    else {
      for (let i = keep; i < next; i++) this.seedOne(i);
    }
  }

  private seedAll() {
    for (let i = 0; i < this.count; i++) this.seedOne(i, true);
  }

  private seedOne(i: number, formation = false) {
    const cx = this.width * 0.5;
    const cy = this.height * 0.5;
    const radius = Math.min(this.width, this.height) * 0.42;
    if (formation) {
      const t = (i + 0.5) / this.count;
      const r = Math.sqrt(t) * radius;
      const a = i * GOLDEN_ANGLE;
      this.x[i] = cx + Math.cos(a) * r;
      this.y[i] = cy + Math.sin(a) * r;
      const spin = 46 + t * 38;
      this.vx[i] = -Math.sin(a) * spin;
      this.vy[i] = Math.cos(a) * spin;
    } else {
      const a = Math.random() * TAU;
      const r = Math.sqrt(Math.random()) * radius;
      this.x[i] = cx + Math.cos(a) * r;
      this.y[i] = cy + Math.sin(a) * r;
      this.vx[i] = (Math.random() - 0.5) * 40;
      this.vy[i] = (Math.random() - 0.5) * 40;
    }
    this.hue[i] = Math.random() * 360;
    this.size[i] = i % 11 === 0 ? 2.4 + Math.random() * 1.4 : 0.9 + Math.random() * 1.2;
    this.phase[i] = Math.random() * TAU;
  }

  private burst(px: number, py: number) {
    const radius = 240;
    const x = this.x;
    const y = this.y;
    const vx = this.vx;
    const vy = this.vy;
    const kick = 180 + this.settings.force * 90;
    for (let i = 0; i < this.count; i++) {
      const dx = x[i] - px;
      const dy = y[i] - py;
      const d = Math.hypot(dx, dy) || 1;
      if (d > radius) continue;
      const k = (1 - d / radius) * kick;
      const nx = dx / d;
      const ny = dy / d;
      vx[i] += nx * k * 0.55 + -ny * k;
      vy[i] += ny * k * 0.55 + nx * k;
    }
    this.rings.push(
      { x: px, y: py, r: 8, vr: 280, life: 0.55, maxLife: 0.55 },
      { x: px, y: py, r: 4, vr: 160, life: 0.38, maxLife: 0.38 },
    );
    if (this.rings.length > 8) this.rings.splice(0, this.rings.length - 8);
  }

  private frame = (now: number) => {
    if (!this.running) return;
    const t = now * 0.001;
    let dt = this.lastTime === 0 ? 1 / 60 : t - this.lastTime;
    this.lastTime = t;
    if (dt > 0.1) dt = 0.1;
    this.time += dt;
    this.step(dt);
    this.draw();
    this.pointerVx *= 0.72;
    this.pointerVy *= 0.72;
    this.raf = requestAnimationFrame(this.frame);
  };

  private attractor(dt: number): { ax: number; ay: number } {
    if (this.hasPointer) {
      return { ax: this.pointerX, ay: this.pointerY };
    }
    const t = this.time;
    const cx = this.width * 0.5;
    const cy = this.height * 0.5;
    const orbit = Math.min(this.width, this.height) * 0.16;
    const targetX = cx + Math.cos(t * 0.23) * orbit;
    const targetY = cy + Math.sin(t * 0.19) * orbit * 0.72;
    const k = 1 - Math.exp(-2.4 * dt);
    this.idleX += (targetX - this.idleX) * k;
    this.idleY += (targetY - this.idleY) * k;
    return { ax: this.idleX, ay: this.idleY };
  }

  private step(dt: number) {
    const { force, palette } = this.settings;
    const { ax: tx, ay: ty } = this.attractor(dt);
    const hold = this.pointerDown;
    const motion = this.reducedMotion ? 0.5 : 1;
    const pull = (hold ? 5600 : 2680) * force * motion;
    const swirl = (hold ? 980 : 3120) * force * motion;
    const drag = hold ? 3.6 : 1.55;
    const damp = Math.exp(-drag * dt);
    const minD = hold ? 18 : 32;
    const time = this.time;
    const w = this.width;
    const h = this.height;
    const x = this.x;
    const y = this.y;
    const vx = this.vx;
    const vy = this.vy;
    const hue = this.hue;
    const phase = this.phase;
    const n = this.count;
    const pvx = this.pointerVx;
    const pvy = this.pointerVy;

    for (let i = 0; i < n; i++) {
      let px = x[i];
      let py = y[i];
      const dx = tx - px;
      const dy = ty - py;
      const dist = Math.hypot(dx, dy) || 1;
      const inv = 1 / Math.max(dist, minD);
      const nx = dx * inv;
      const ny = dy * inv;
      const falloff = 110 * inv;
      const aPull = pull * falloff;
      const aSwirl = swirl * falloff;
      let avx = vx[i] + (nx * aPull + -ny * aSwirl) * dt;
      let avy = vy[i] + (ny * aPull + nx * aSwirl) * dt;

      const ph = phase[i] + time;
      avx += Math.sin(ph * 1.7 + px * 0.012) * 18 * dt;
      avy += Math.cos(ph * 1.3 + py * 0.012) * 18 * dt;

      const near = Math.max(0, 1 - dist / 160);
      avx += pvx * near * 2.6;
      avy += pvy * near * 2.6;

      avx *= damp;
      avy *= damp;

      const spd = Math.hypot(avx, avy);
      const maxSpd = 1480 * force;
      if (spd > maxSpd) {
        const s = maxSpd / spd;
        avx *= s;
        avy *= s;
      }

      px += avx * dt;
      py += avy * dt;

      const m = 48;
      if (px < -m) px = w + m;
      else if (px > w + m) px = -m;
      if (py < -m) py = h + m;
      else if (py > h + m) py = -m;

      x[i] = px;
      y[i] = py;
      vx[i] = avx;
      vy[i] = avy;

      if (palette === "prism") {
        hue[i] =
          ((Math.atan2(dy, dx) * 180) / Math.PI + 180 + time * 28 + phase[i] * 12) % 360;
      }
    }

    for (let i = this.rings.length - 1; i >= 0; i--) {
      const ring = this.rings[i];
      ring.life -= dt;
      ring.r += ring.vr * dt;
      if (ring.life <= 0) this.rings.splice(i, 1);
    }
  }

  private particleColor(
    i: number,
    speed: number,
    dist: number,
  ): [number, number, number, number] {
    const palette: PaletteId = this.settings.palette;
    const paper = this.settings.background === "paper";
    const t = this.time;
    const spark = i % 11 === 0;
    let h = this.hue[i];
    let s = 62;
    let l = 58;
    const speedN = Math.min(speed / 420, 1);
    const near = Math.max(0, 1 - dist / 280);

    if (palette === "aurora") {
      h = 168 + Math.sin(this.phase[i] + t * 0.35) * 26 + speedN * 18;
      s = 58 + near * 18;
      l = 52 + speedN * 22 + (spark ? 10 : 0);
    } else if (palette === "ember") {
      h = 22 + Math.sin(this.phase[i] * 2 + t * 0.4) * 14 + speedN * 10;
      s = 72 + near * 12;
      l = 50 + speedN * 18 + (spark ? 8 : 0);
    } else if (palette === "ice") {
      h = 204 + Math.sin(this.phase[i] + t * 0.2) * 10;
      s = 28 + speedN * 22 + near * 10;
      l = 72 + speedN * 14 + (spark ? 8 : 0);
    } else {
      s = 64 + near * 16;
      l = 54 + speedN * 20 + (spark ? 8 : 0);
    }

    if (paper) {
      s = Math.min(s + 8, 86);
      l = Math.min(Math.max(l - 18, 28), 48);
    }

    const [r, g, b] = hslToRgb(h, s, l);
    const alpha = paper
      ? 0.55 + speedN * 0.35
      : 0.42 + speedN * 0.45 + (spark ? 0.12 : 0);
    return [r, g, b, Math.min(alpha, 0.95)];
  }

  private draw() {
    const ctx = this.ctx;
    const w = this.width;
    const h = this.height;
    const bg = BACKGROUNDS[this.settings.background as BackgroundId];
    const [br, bgc, bb] = bg.rgb;
    const additive = this.settings.background !== "paper";
    const trail = this.reducedMotion ? this.settings.trail * 0.45 : this.settings.trail;
    const fade = this.needsHardClear ? 1 : 0.22 * (1 - trail) + 0.028;

    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = `rgba(${br},${bgc},${bb},${fade})`;
    ctx.fillRect(0, 0, w, h);
    this.needsHardClear = false;

    const { ax, ay } = this.hasPointer
      ? { ax: this.pointerX, ay: this.pointerY }
      : { ax: this.idleX, ay: this.idleY };

    this.drawWell(ctx, ax, ay, additive);

    if (additive) ctx.globalCompositeOperation = "lighter";

    const x = this.x;
    const y = this.y;
    const vx = this.vx;
    const vy = this.vy;
    const size = this.size;
    const n = this.count;
    const skipGlow = n > 3200;

    for (let i = 0; i < n; i++) {
      const px = x[i];
      const py = y[i];
      const avx = vx[i];
      const avy = vy[i];
      const speed = Math.hypot(avx, avy);
      const dist = Math.hypot(ax - px, ay - py);
      const [r, g, b, a] = this.particleColor(i, speed, dist);
      const rad = size[i] * (1 + Math.min(speed * 0.0024, 1.1));
      const stretch = 1 + Math.min(speed * 0.016, 3.4);
      const ang = Math.atan2(avy, avx);
      const rx = rad * stretch;
      const ry = rad / Math.sqrt(stretch);

      ctx.fillStyle = `rgba(${r},${g},${b},${a})`;
      ctx.beginPath();
      ctx.ellipse(px, py, rx, ry, ang, 0, TAU);
      ctx.fill();

      if (!skipGlow && i % 3 === 0) {
        ctx.fillStyle = `rgba(${r},${g},${b},${a * 0.22})`;
        ctx.beginPath();
        ctx.ellipse(px, py, rx * 2.1, ry * 2.1, ang, 0, TAU);
        ctx.fill();
      }
    }

    this.drawRings(ctx, additive);
    ctx.globalCompositeOperation = "source-over";
  }

  private drawWell(
    ctx: CanvasRenderingContext2D,
    ax: number,
    ay: number,
    additive: boolean,
  ) {
    const hold = this.pointerDown;
    const radius = hold ? 26 : 38;
    const pulse = 0.82 + Math.sin(this.time * 3.2) * 0.08;
    const grad = ctx.createRadialGradient(ax, ay, 0, ax, ay, radius * 4.2 * pulse);
    if (additive) {
      grad.addColorStop(0, "rgba(210, 236, 236, 0.28)");
      grad.addColorStop(0.22, "rgba(142, 200, 201, 0.12)");
      grad.addColorStop(1, "rgba(142, 200, 201, 0)");
    } else {
      grad.addColorStop(0, "rgba(40, 48, 52, 0.22)");
      grad.addColorStop(1, "rgba(40, 48, 52, 0)");
    }
    ctx.globalCompositeOperation = additive ? "lighter" : "source-over";
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(ax, ay, radius * 4.2 * pulse, 0, TAU);
    ctx.fill();

    ctx.globalCompositeOperation = "source-over";
    ctx.strokeStyle = hold ? "rgba(236, 236, 232, 0.85)" : "rgba(236, 236, 232, 0.45)";
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.arc(ax, ay, hold ? 10 : 14, 0, TAU);
    ctx.stroke();
    ctx.fillStyle = "rgba(236, 236, 232, 0.92)";
    ctx.beginPath();
    ctx.arc(ax, ay, 2.2, 0, TAU);
    ctx.fill();
  }

  private drawRings(ctx: CanvasRenderingContext2D, additive: boolean) {
    for (const ring of this.rings) {
      const t = ring.life / ring.maxLife;
      const alpha = t * (additive ? 0.55 : 0.35);
      ctx.strokeStyle = `rgba(220, 232, 232, ${alpha})`;
      ctx.lineWidth = 1.5 * t + 0.4;
      ctx.beginPath();
      ctx.arc(ring.x, ring.y, ring.r, 0, TAU);
      ctx.stroke();
    }
  }
}
