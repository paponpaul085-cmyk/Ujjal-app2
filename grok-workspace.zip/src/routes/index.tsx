import { createFileRoute } from "@tanstack/react-router";
import { ControlDock } from "@/components/control-dock";
import { FieldCanvas } from "@/components/field-canvas";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="relative h-dvh overflow-hidden bg-bg text-fg">
      <FieldCanvas />
      <ControlDock />
    </main>
  );
}
